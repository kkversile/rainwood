export const API = process.env.NEXT_PUBLIC_API_BASE_URL ?? process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000/api/v1';

export function apiAssetUrl(value?: string | null) {
  if (!value) return '';
  const marker = '/files/public/';
  const markerIndex = value.indexOf(marker);
  return markerIndex >= 0 ? `${API}${value.slice(markerIndex)}` : value;
}

export async function apiFileBlob(path: string) {
  const token = browserToken();
  const response = await fetch(`${API}${path}`, { credentials: 'include', headers: token ? { Authorization: `Bearer ${token}` } : undefined, cache: 'no-store' });
  if (!response.ok) throw new Error(`Could not load file (${response.status})`);
  return response.blob();
}

let accessToken: string | null = null;

function browserToken() {
  if (typeof window === 'undefined') return accessToken;
  return accessToken ?? window.localStorage.getItem('rainwood_access_token');
}

export function setAccessToken(token: string | null, role?: string) {
  accessToken = token;
  if (typeof window !== 'undefined') {
    if (token) window.localStorage.setItem('rainwood_access_token', token);
    else {
      window.localStorage.removeItem('rainwood_access_token');
    }
    window.dispatchEvent(new Event('rainwood-auth-change'));
  }
}

export function clearAccessToken() { setAccessToken(null); }

function redirectToLoginAfterUnauthorized() {
  if (typeof window === 'undefined') return;
  clearAccessToken();
  const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? '';
  const loginPath = `${basePath}/login?next=${encodeURIComponent(`${window.location.pathname}${window.location.search}`)}`;
  if (!window.location.pathname.startsWith(`${basePath}/login`)) window.location.replace(loginPath);
}

async function readBody(response: Response) {
  const text = await response.text();
  if (!text) return null;
  try { return JSON.parse(text); } catch { return { message: text }; }
}

export function friendlyApiError(status: number, body: any) {
  const raw = Array.isArray(body?.message)
    ? body.message.join(', ')
    : typeof body?.message === 'object' && body.message
      ? body.message.message ?? JSON.stringify(body.message)
      : body?.message;
  const message = String(raw ?? '').replace(/^(BadRequest|Conflict|Forbidden|NotFound)Exception:\s*/i, '').trim();
  if (/active_assignment_exists|room already occupied|room_assignment_conflict/i.test(message)) return 'This room is already occupied. Choose another available room.';
  if (status === 401) return 'Your session has expired. Sign in again to continue.';
  if (status === 403) return 'You do not have permission to perform this action.';
  if (status === 404) return 'The requested record could not be found. Refresh and try again.';
  if (status === 409) return 'This record conflicts with another operation. Refresh and try again.';
  return message || `Request failed (${status})`;
}

export async function apiRequest<T>(path: string, init: RequestInit = {}, retry = true): Promise<T> {
  const token = browserToken();
  const headers = new Headers(init.headers);
  if (init.body && !headers.has('Content-Type') && !(init.body instanceof FormData)) headers.set('Content-Type', 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);
  let response: Response;
  try {
    response = await fetch(`${API}${path}`, { ...init, headers, credentials: 'include', cache: 'no-store' });
  } catch {
    throw new Error(`RainWood API is unavailable. Start the backend and confirm it is listening at ${API}.`);
  }
  if (response.status === 401 && retry && !path.startsWith('/auth/')) {
    const refreshed = await fetch(`${API}/auth/refresh`, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' } });
    if (refreshed.ok) {
      const body = await readBody(refreshed) as { accessToken?: string } | null;
      if (body?.accessToken) { setAccessToken(body.accessToken); return apiRequest<T>(path, init, false); }
    }
  }
  if (response.status === 401 && !path.startsWith('/auth/')) redirectToLoginAfterUnauthorized();
  const body = await readBody(response);
  if (!response.ok) {
    throw new Error(friendlyApiError(response.status, body));
  }
  return body as T;
}

export function publicApi<T>(path: string) { return apiRequest<T>(path); }
