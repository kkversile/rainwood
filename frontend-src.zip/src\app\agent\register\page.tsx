'use client';

import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { apiRequest } from '../../../lib/api';

type AgentForm = { companyName: string; contactPerson: string; email: string; mobile: string; gstin: string; place: string; addressLine1: string; addressLine2: string; state: string; pinCode: string; additionalInformation: string; password: string; confirm: string };
const initialForm: AgentForm = { companyName: '', contactPerson: '', email: '', mobile: '', gstin: '', place: '', addressLine1: '', addressLine2: '', state: '', pinCode: '', additionalInformation: '', password: '', confirm: '' };

export default function AgentRegister() {
  const router = useRouter();
  const [form, setForm] = useState(initialForm);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [busy, setBusy] = useState(false);
  function update(field: keyof AgentForm, value: string) { setForm((current) => ({ ...current, [field]: value })); }
  async function submit(event: FormEvent) {
    event.preventDefault(); setError('');
    if (form.password !== form.confirm) { setError('Passwords do not match.'); return; }
    setBusy(true);
    try { await apiRequest('/auth/agent/register', { method: 'POST', body: JSON.stringify({ companyName: form.companyName, contactPerson: form.contactPerson, email: form.email, mobile: form.mobile, gstin: form.gstin, place: form.place, addressLine1: form.addressLine1, addressLine2: form.addressLine2, state: form.state, pinCode: form.pinCode, additionalInformation: form.additionalInformation, password: form.password }) }); setSuccess(true); }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'Registration failed'); }
    finally { setBusy(false); }
  }
  if (success) return <main className="login"><section className="formCard"><h1>Registration successful</h1><p>You can now sign in to complete your KYC and onboarding. Hotel and booking access will be enabled after Admin approval.</p><Link className="btn full" href={`/agent/login?email=${encodeURIComponent(form.email)}&registered=1`}>Sign In</Link><p><button className="textLink" type="button" onClick={() => router.replace('/agent/login')}>Use another account</button></p></section></main>;
  return <main className="login"><form className="formCard agentRegistrationForm" onSubmit={(event) => void submit(event)}><h1>Agent Registration</h1><p>Request access to RainWood Hotels travel partner rates and bookings.</p>{error && <p className="error" role="alert">{error}</p>}<h2>Agency information</h2><div className="two"><label>Company name *<input value={form.companyName} onChange={(event) => update('companyName', event.target.value)} required /></label><label>Contact person *<input value={form.contactPerson} onChange={(event) => update('contactPerson', event.target.value)} autoComplete="name" required /></label></div><div className="two"><label>Email address *<input type="email" value={form.email} onChange={(event) => update('email', event.target.value)} autoComplete="email" required /></label><label>Mobile number *<input type="tel" value={form.mobile} onChange={(event) => update('mobile', event.target.value)} required /></label></div><div className="two"><label>GSTIN (Optional)<input value={form.gstin} onChange={(event) => update('gstin', event.target.value)} /></label><label>Place<input value={form.place} onChange={(event) => update('place', event.target.value)} /></label></div><h2>Address information</h2><label>Address line 1 *<input value={form.addressLine1} onChange={(event) => update('addressLine1', event.target.value)} required /></label><label>Address line 2<input value={form.addressLine2} onChange={(event) => update('addressLine2', event.target.value)} /></label><div className="two"><label>State<input value={form.state} onChange={(event) => update('state', event.target.value)} /></label><label>PIN code<input inputMode="numeric" value={form.pinCode} onChange={(event) => update('pinCode', event.target.value)} /></label></div><label>Additional information<textarea rows={3} value={form.additionalInformation} onChange={(event) => update('additionalInformation', event.target.value)} /></label><p className="mutedText">Optional. Tell us about your agency, destinations served, or business profile.</p><h2>Login access</h2><div className="two"><label>Password *<input type="password" minLength={8} value={form.password} onChange={(event) => update('password', event.target.value)} autoComplete="new-password" required /></label><label>Confirm password *<input type="password" minLength={8} value={form.confirm} onChange={(event) => update('confirm', event.target.value)} autoComplete="new-password" required /></label></div><p className="mutedText">You can sign in after registration to complete KYC while Admin reviews your application.</p><button className="btn full" disabled={busy}>{busy ? 'Submitting request...' : 'Request agent access'}</button><p><Link href="/agent/login">Already registered? Sign in</Link></p></form></main>;
}
