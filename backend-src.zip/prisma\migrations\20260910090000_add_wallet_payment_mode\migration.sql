-- AlterEnum
ALTER TYPE "PaymentMode" ADD VALUE 'WALLET';
