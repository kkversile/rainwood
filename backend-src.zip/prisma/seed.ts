import { PrismaClient, UserRole } from '@prisma/client';
import { PrismaPg } from '@prisma/adapter-pg';
import { Pool } from 'pg';
import bcrypt from 'bcryptjs';
import { FEATURE_KEYS } from '../src/modules/features/features.catalog';

const connectionString = process.env.DATABASE_URL ?? '';
const requiresTls = /(?:\?|&)sslmode=require(?:&|$)/i.test(connectionString);
const pool = new Pool({ connectionString, ...(requiresTls ? { ssl: { rejectUnauthorized: true } } : {}) });
const prisma = new PrismaClient({ adapter: new PrismaPg(pool) });

async function main() {
  const seedPassword = process.env.SEED_ADMIN_PASSWORD ?? 'change_me_after_seed';
  const passwordHash = await bcrypt.hash(seedPassword, 12);
  const admin = await prisma.user.upsert({ where: { email: 'admin@rainwood.demo' }, update: { active: true, role: 'SUPER_ADMIN', passwordHash, failedLoginCount: 0, lockedUntil: null }, create: { email: 'admin@rainwood.demo', name: 'RainWood Admin', passwordHash, role: 'SUPER_ADMIN' } });
  const reservationUser = await prisma.user.upsert({ where: { email: 'reservation@rainwood.demo' }, update: { active: true, role: 'RESERVATION', passwordHash }, create: { email: 'reservation@rainwood.demo', name: 'Reservation Desk', passwordHash, role: 'RESERVATION' } });
  await prisma.user.upsert({ where: { email: 'accounts@rainwood.demo' }, update: { active: true, role: 'ACCOUNTS', passwordHash }, create: { email: 'accounts@rainwood.demo', name: 'Accounts Team', passwordHash, role: 'ACCOUNTS' } });
  await prisma.user.upsert({ where: { email: 'viewer@rainwood.demo' }, update: { active: true, role: 'VIEWER', passwordHash }, create: { email: 'viewer@rainwood.demo', name: 'RainWood Viewer', passwordHash, role: 'VIEWER' } });

  const permissions = [
    ['RESERVATION_READ', 'Read reservations'],
    ['RESERVATION_WRITE', 'Create and modify reservations'],
    ['PAYMENT_RECORD', 'Record manual payments'],
    ['PAYMENT_VERIFY', 'Verify manual payments'],
    ['CONTENT_MANAGE', 'Manage public hotel content'],
    ['REPORT_READ', 'Read operational reports'],
    ['HOTEL_OPERATIONS_READ', 'Read hotel operations'],
    ['RATE_MANAGE', 'Manage rates and promotions'],
    ['HOUSEKEEPING_MANAGE', 'Manage housekeeping'],
    ['MAINTENANCE_MANAGE', 'Manage maintenance'],
    ['NIGHT_AUDIT_READ', 'Read and run night audit'],
    ['CRM_READ', 'Read guest CRM'],
    ['HOTEL_CREATE', 'Create global hotels'],
    ['SYSTEM_SETTINGS', 'Manage system settings'],
    ['SYSTEM_SECURITY', 'Manage system security'],
    ['GLOBAL_AUDIT_READ', 'Read global audit logs'],
    ['JOBS_RETRY', 'Retry global integration jobs'],
    ['USER_MANAGE', 'Manage internal users'],
  ] as const;
  for (const [code, description] of permissions) await prisma.permission.upsert({ where: { code }, update: { description }, create: { code, description } });
  // RolePermission is advisory metadata; @Roles plus hotel-scope service checks remain authoritative.
  const business = ['RESERVATION_READ', 'RESERVATION_WRITE', 'PAYMENT_RECORD', 'PAYMENT_VERIFY', 'CONTENT_MANAGE', 'REPORT_READ', 'HOTEL_OPERATIONS_READ', 'RATE_MANAGE', 'HOUSEKEEPING_MANAGE', 'MAINTENANCE_MANAGE', 'NIGHT_AUDIT_READ', 'CRM_READ'];
  const roleCodes: Record<string, string[]> = {
    SUPER_ADMIN: permissions.map(([code]) => code),
    CORPORATE_ADMIN: business.concat(['USER_MANAGE']),
    ADMIN: business.concat(['USER_MANAGE']),
    RESERVATION: ['RESERVATION_READ', 'RESERVATION_WRITE', 'REPORT_READ', 'HOTEL_OPERATIONS_READ'],
    ACCOUNTS: ['RESERVATION_READ', 'PAYMENT_RECORD', 'PAYMENT_VERIFY', 'REPORT_READ'],
    VIEWER: ['RESERVATION_READ', 'REPORT_READ', 'HOTEL_OPERATIONS_READ'],
    SERVICE_STAFF: ['HOTEL_OPERATIONS_READ'],
    AGENT: ['RESERVATION_READ', 'RESERVATION_WRITE'],
  };
  for (const role of Object.keys(roleCodes) as UserRole[]) {
    await prisma.rolePermission.deleteMany({ where: { role } });
    for (const code of roleCodes[role]) {
      const permission = await prisma.permission.findUniqueOrThrow({ where: { code } });
      await prisma.rolePermission.upsert({ where: { role_permissionId: { role, permissionId: permission.id } }, update: {}, create: { role, permissionId: permission.id } });
    }
  }

  const hotel = await prisma.hotel.upsert({ where: { code: 'RW-KODAI' }, update: { active: true, name: 'RainWood Aurum Kodaikanal', city: 'Kodaikanal', description: 'A calm RainWood property with valley views and direct reservation support.', seoTitle: 'RainWood Aurum Kodaikanal | Direct Booking', seoDescription: 'Book RainWood Aurum Kodaikanal directly for transparent rates and secure confirmation.', canonicalPath: '/hotels/rainwood-aurum-kodaikanal', axisPropertyId: 'AXIS-RW-KODAI' }, create: { code: 'RW-KODAI', name: 'RainWood Aurum Kodaikanal', slug: 'rainwood-aurum-kodaikanal', city: 'Kodaikanal', description: 'A calm RainWood property with valley views and direct reservation support.', seoTitle: 'RainWood Aurum Kodaikanal | Direct Booking', seoDescription: 'Book RainWood Aurum Kodaikanal directly for transparent rates and secure confirmation.', canonicalPath: '/hotels/rainwood-aurum-kodaikanal', axisPropertyId: 'AXIS-RW-KODAI' } });
  await prisma.user.updateMany({ where: { email: 'reservation@rainwood.demo', role: 'RESERVATION' }, data: { staffHotelId: hotel.id, active: true, tokenVersion: { increment: 1 } } });
  await prisma.user.upsert({ where: { email: 'corporate@rainwood.demo' }, update: { name: 'RainWood Corporate Admin', passwordHash, role: 'CORPORATE_ADMIN', staffHotelId: null, active: true }, create: { email: 'corporate@rainwood.demo', name: 'RainWood Corporate Admin', passwordHash, role: 'CORPORATE_ADMIN', active: true } });
  await prisma.user.upsert({ where: { email: 'hotel.admin@rainwood.demo' }, update: { name: 'RainWood Property Admin', passwordHash, role: 'ADMIN', staffHotelId: hotel.id, active: true }, create: { email: 'hotel.admin@rainwood.demo', name: 'RainWood Property Admin', passwordHash, role: 'ADMIN', staffHotelId: hotel.id, active: true } });
  for (const amenityValue of [['WIFI', 'High-speed Wi-Fi'], ['BREAKFAST', 'Breakfast available'], ['PARKING', 'On-site parking']] as const) {
    const amenity = await prisma.amenity.upsert({ where: { code: amenityValue[0] }, update: { name: amenityValue[1] }, create: { code: amenityValue[0], name: amenityValue[1] } });
    await prisma.hotelAmenity.upsert({ where: { hotelId_amenityId: { hotelId: hotel.id, amenityId: amenity.id } }, update: {}, create: { hotelId: hotel.id, amenityId: amenity.id } });
  }
  const room = await prisma.roomType.upsert({ where: { hotelId_code: { hotelId: hotel.id, code: 'PVR' } }, update: { active: true, name: 'Premium Valley Room', maxAdults: 3, maxChildren: 2, maxOccupancy: 4, axisRoomId: 'AXIS-ROOM-PVR' }, create: { hotelId: hotel.id, code: 'PVR', name: 'Premium Valley Room', description: 'A bright room with valley views.', maxAdults: 3, maxChildren: 2, maxOccupancy: 4, axisRoomId: 'AXIS-ROOM-PVR' } });
  const demoRooms = [
    { id: 'seed-physical-room-203', roomNumber: '203', floor: '2', wing: 'East' },
    { id: 'seed-physical-room-204', roomNumber: '204', floor: '2', wing: 'East' },
    { id: 'seed-physical-room-205', roomNumber: '205', floor: '2', wing: 'West' },
  ];
  const seededRooms = [] as { id: string; roomNumber: string }[];
  for (const physicalRoom of demoRooms) {
    const seededRoom = await prisma.room.upsert({ where: { hotelId_roomNumber: { hotelId: hotel.id, roomNumber: physicalRoom.roomNumber } }, update: { roomTypeId: room.id, floor: physicalRoom.floor, wing: physicalRoom.wing, active: true }, create: { ...physicalRoom, hotelId: hotel.id, roomTypeId: room.id, status: 'AVAILABLE', active: true } });
    seededRooms.push({ id: seededRoom.id, roomNumber: seededRoom.roomNumber });
  }
  const canonicalDefinitions = [
    { code: 'EP', name: 'EP - Room Only', mealPlan: 'EP', description: 'Room only.' },
    { code: 'CP', name: 'CP - Breakfast', mealPlan: 'CP', description: 'Room with breakfast included.' },
    { code: 'MAP', name: 'MAP - Breakfast + Dinner', mealPlan: 'MAP', description: 'Room with breakfast and dinner included.' },
    { code: 'AP', name: 'AP - All Meals', mealPlan: 'AP', description: 'Room with all meals included.' },
  ] as const;
  const canonicalPlans = [] as { id: string; code: string; mealPlan: string }[];
  for (const item of canonicalDefinitions) {
    const master = await prisma.ratePlanMaster.upsert({ where: { hotelId_code: { hotelId: hotel.id, code: item.code } }, update: { active: true, name: item.name, mealPlan: item.mealPlan, kind: 'CANONICAL_MEAL', description: item.description }, create: { hotelId: hotel.id, code: item.code, name: item.name, mealPlan: item.mealPlan, kind: 'CANONICAL_MEAL', description: item.description } });
    const assignment = await prisma.ratePlan.upsert({ where: { roomTypeId_masterId: { roomTypeId: room.id, masterId: master.id } }, update: { active: true, code: master.code, name: master.name, mealPlan: master.mealPlan, description: master.description, axisRatePlanId: `AXIS-RATE-${item.code}` }, create: { roomTypeId: room.id, masterId: master.id, code: master.code, name: master.name, mealPlan: master.mealPlan, description: master.description, axisRatePlanId: `AXIS-RATE-${item.code}` } });
    canonicalPlans.push({ id: assignment.id, code: item.code, mealPlan: item.mealPlan });
  }
  const plan = canonicalPlans.find((item) => item.code === 'CP')!;
  const masterPlans = [
    { code: 'A', name: 'Preferred Partner Rate', mealPlan: 'EP', description: 'Plan A - Nett contract', amount: 4800, taxAmount: 576 },
    { code: 'B', name: 'Contracted Nett Rate', mealPlan: 'EP', description: 'Plan B - Nett contract', amount: 5000, taxAmount: 600 },
    { code: 'C', name: 'Premium Meal Rate', mealPlan: 'CP', description: 'Plan C - Premium meal inclusion', amount: 6000, taxAmount: 720 },
    { code: 'D', name: 'Standard B2B Rate', mealPlan: 'CP', description: 'Plan D - Standard B2B contract', amount: 5200, taxAmount: 624 },
    { code: 'E', name: 'Standard Public Rate', mealPlan: 'MAP', description: 'Plan E - Public flexible rate', amount: 6500, taxAmount: 780 },
  ] as const;
  const seededMasterPlans = [] as { id: string; code: string; amount: number; taxAmount: number }[];
  for (const item of masterPlans) {
    const definition = await prisma.ratePlanMaster.upsert({ where: { hotelId_code: { hotelId: hotel.id, code: item.code } }, update: { active: true, name: item.name, mealPlan: item.mealPlan, kind: 'LEGACY', description: item.description }, create: { hotelId: hotel.id, code: item.code, name: item.name, mealPlan: item.mealPlan, kind: 'LEGACY', description: item.description } });
    const assignment = await prisma.ratePlan.upsert({ where: { roomTypeId_masterId: { roomTypeId: room.id, masterId: definition.id } }, update: { active: true, code: definition.code, name: definition.name, mealPlan: definition.mealPlan, description: definition.description, axisRatePlanId: `AXIS-RATE-${item.code}` }, create: { roomTypeId: room.id, masterId: definition.id, code: definition.code, name: definition.name, mealPlan: definition.mealPlan, description: definition.description, axisRatePlanId: `AXIS-RATE-${item.code}` } });
    seededMasterPlans.push({ id: assignment.id, code: item.code, amount: item.amount, taxAmount: item.taxAmount });
    await prisma.cancellationRule.upsert({ where: { hotelId_ratePlanId_type: { hotelId: hotel.id, ratePlanId: assignment.id, type: 'FREE_CANCELLATION' } }, update: { cutoffHours: 48, value: 0, active: true }, create: { hotelId: hotel.id, ratePlanId: assignment.id, type: 'FREE_CANCELLATION', cutoffHours: 48, value: 0 } });
  }
  const agentPasswordHash = await bcrypt.hash(process.env.SEED_AGENT_PASSWORD ?? 'Agent@Rainwood2026!', 12);
  const seededAgents = [
    { email: 'agent@rainwood.demo', name: 'RainWood Existing Agent' },
    { email: 'munnar.agent@rainwood.demo', name: 'Munnar Travel Partner' },
    { email: 'south.agent@rainwood.demo', name: 'South India Holidays' },
  ];
  const agentUsers = [] as { id: string; email: string }[];
  for (const item of seededAgents) {
    const agentUser = await prisma.user.upsert({ where: { email: item.email }, update: { name: item.name, passwordHash: agentPasswordHash, role: 'AGENT', active: true, agentPaymentPolicy: 'PERCENTAGE', bookingPaymentPercent: 100 }, create: { email: item.email, name: item.name, passwordHash: agentPasswordHash, role: 'AGENT', active: true, agentPaymentPolicy: 'PERCENTAGE', bookingPaymentPercent: 100 } });
    agentUsers.push({ id: agentUser.id, email: agentUser.email });
    await prisma.agentWallet.upsert({ where: { agentId: agentUser.id }, update: {}, create: { agentId: agentUser.id, balance: 0 } });
  }
  const planByCode = Object.fromEntries(seededMasterPlans.map((item) => [item.code, item.id]));
  const agentAssignments = [[agentUsers[0].id, ['A']], [agentUsers[1].id, ['C']], [agentUsers[2].id, ['B']]] as const;
  for (const [agentId, codes] of agentAssignments) {
    const selectedPlanIds = codes.map((code) => planByCode[code]);
    for (const ratePlanId of selectedPlanIds) await prisma.agentRatePlan.upsert({ where: { agentId_ratePlanId: { agentId, ratePlanId } }, create: { agentId, ratePlanId, active: true }, update: { active: true } });
    await prisma.agentRatePlan.updateMany({ where: { agentId, ratePlanId: { notIn: selectedPlanIds } }, data: { active: false } });
  }
  await prisma.cancellationRule.upsert({ where: { hotelId_ratePlanId_type: { hotelId: hotel.id, ratePlanId: plan.id, type: 'FREE_CANCELLATION' } }, update: { cutoffHours: 48, value: 0, active: true }, create: { hotelId: hotel.id, ratePlanId: plan.id, type: 'FREE_CANCELLATION', cutoffHours: 48, value: 0 } });
  const today = new Date();
  const start = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()));
  const taxEffectiveFrom = new Date(Date.UTC(today.getUTCFullYear(), 0, 1));
  const taxEffectiveTo = new Date(Date.UTC(today.getUTCFullYear() + 10, 11, 31));
  await prisma.hotelTaxProfile.upsert({
    where: { id: 'seed-hotel-tax-profile' },
    update: { hotelId: hotel.id, legalName: 'RainWood Hospitality Services Private Limited', tradeName: 'RainWood Aurum Kodaikanal', gstin: '33AAECR1234K1Z5', gstRegistered: true, registeredAddress: 'Survey 12, Observatory Road', city: 'Kodaikanal', state: 'Tamil Nadu', stateCode: '33', postalCode: '624101', country: 'India', invoicePrefix: 'INV', creditNotePrefix: 'CN', active: true },
    create: { id: 'seed-hotel-tax-profile', hotelId: hotel.id, legalName: 'RainWood Hospitality Services Private Limited', tradeName: 'RainWood Aurum Kodaikanal', gstin: '33AAECR1234K1Z5', gstRegistered: true, registeredAddress: 'Survey 12, Observatory Road', city: 'Kodaikanal', state: 'Tamil Nadu', stateCode: '33', postalCode: '624101', country: 'India', invoicePrefix: 'INV', creditNotePrefix: 'CN', active: true },
  });
  await prisma.hotelTaxProfile.updateMany({ where: { hotelId: hotel.id, id: { not: 'seed-hotel-tax-profile' } }, data: { active: false } });
  const taxRules = [
    { id: 'seed-tax-rule-room', name: 'Room accommodation GST', taxCategory: 'ROOM' as const, serviceCode: '996311', ratePercent: 12, description: 'GST for room accommodation.' },
    { id: 'seed-tax-rule-food', name: 'Food and beverage GST', taxCategory: 'FOOD_BEVERAGE' as const, serviceCode: '996331', ratePercent: 5, description: 'GST for food and beverage services.' },
    { id: 'seed-tax-rule-laundry', name: 'Laundry services GST', taxCategory: 'LAUNDRY' as const, serviceCode: '999712', ratePercent: 18, description: 'GST for guest laundry services.' },
  ];
  for (const taxRule of taxRules) {
    await prisma.taxRule.upsert({ where: { id: taxRule.id }, update: { hotelId: hotel.id, name: taxRule.name, taxCategory: taxRule.taxCategory, serviceCode: taxRule.serviceCode, description: taxRule.description, ratePercent: taxRule.ratePercent, effectiveFrom: taxEffectiveFrom, effectiveTo: taxEffectiveTo, active: true }, create: { ...taxRule, hotelId: hotel.id, effectiveFrom: taxEffectiveFrom, effectiveTo: taxEffectiveTo, active: true } });
  }
  for (let offset = 0; offset < 120; offset += 1) {
    const date = new Date(start.getTime() + offset * 86_400_000);
    await prisma.inventoryDay.upsert({ where: { roomTypeId_date: { roomTypeId: room.id, date } }, update: { available: 8, stopSell: false }, create: { roomTypeId: room.id, date, available: 8, updatedFromAxisAt: new Date() } });
    await prisma.rateDay.upsert({ where: { ratePlanId_date: { ratePlanId: plan.id, date } }, update: { amount: 5500, taxAmount: 660, childAmount: 1000, extraAdultAmount: 1500, occupancyPrices: { single: 5000, double: 5500, triple: 6500, quad: 7500 }, cta: false, ctd: false, minLos: 1, maxLos: 30 }, create: { ratePlanId: plan.id, date, amount: 5500, taxAmount: 660, childAmount: 1000, extraAdultAmount: 1500, occupancyPrices: { single: 5000, double: 5500, triple: 6500, quad: 7500 }, minLos: 1, maxLos: 30, updatedFromAxisAt: new Date() } });
  }
  for (const masterPlan of seededMasterPlans) for (let offset = 0; offset < 120; offset += 1) {
    const date = new Date(start.getTime() + offset * 86_400_000);
    const occupancyPrices = { single: masterPlan.amount - 500, double: masterPlan.amount, triple: masterPlan.amount + 1000, quad: masterPlan.amount + 2000 };
    await prisma.rateDay.upsert({ where: { ratePlanId_date: { ratePlanId: masterPlan.id, date } }, update: { amount: masterPlan.amount, taxAmount: masterPlan.taxAmount, childAmount: 1000, extraAdultAmount: 1500, occupancyPrices, cta: false, ctd: false, minLos: 1, maxLos: 30 }, create: { ratePlanId: masterPlan.id, date, amount: masterPlan.amount, taxAmount: masterPlan.taxAmount, childAmount: 1000, extraAdultAmount: 1500, occupancyPrices, minLos: 1, maxLos: 30, updatedFromAxisAt: new Date() } });
  }
  await prisma.hotelImage.upsert({ where: { id: 'seed-hotel-image' }, update: { published: true }, create: { id: 'seed-hotel-image', hotelId: hotel.id, url: '/rainwood-placeholder.svg', altText: 'RainWood Aurum Kodaikanal exterior', sortOrder: 0 } });
  await prisma.roomImage.upsert({ where: { id: 'seed-room-image' }, update: { published: true }, create: { id: 'seed-room-image', roomTypeId: room.id, url: '/rainwood-placeholder.svg', altText: 'Premium Valley Room at RainWood Aurum', sortOrder: 0 } });
  const demoDate = (offset: number) => new Date(start.getTime() + offset * 86_400_000);
  const demoReservations = [
    { reference: 'RW-DEMO-001', guestName: 'Ananya Rao', email: 'ananya.rao@example.com', mobile: '+91 90000 10001', source: 'WEBSITE' as const, status: 'CONFIRMED' as const, paymentStatus: 'PARTIALLY_PAID' as const, syncStatus: 'SYNCED' as const, arrivalOffset: 3, total: 12320, tax: 1320, advance: 6000, balance: 6320, adults: 2, children: 0 },
    { reference: 'RW-DEMO-002', guestName: 'Vikram Menon', email: 'vikram.menon@example.com', mobile: '+91 90000 10002', source: 'DIRECT' as const, status: 'PENDING_PAYMENT' as const, paymentStatus: 'PENDING' as const, syncStatus: 'PENDING' as const, arrivalOffset: 10, total: 12320, tax: 1320, advance: 0, balance: 12320, adults: 2, children: 1 },
    { reference: 'RW-DEMO-003', guestName: 'Meera Shah', email: 'meera.shah@example.com', mobile: '+91 90000 10003', source: 'PHONE' as const, status: 'COMPLETED' as const, paymentStatus: 'PAID' as const, syncStatus: 'SYNCED' as const, arrivalOffset: -20, total: 12320, tax: 1320, advance: 12320, balance: 0, adults: 2, children: 0 },
    { reference: 'RW-DEMO-004', guestName: 'Arjun Kapoor', email: 'arjun.kapoor@example.com', mobile: '+91 90000 10004', source: 'AGENT' as const, status: 'CANCELLED' as const, paymentStatus: 'REFUNDED' as const, syncStatus: 'PENDING' as const, arrivalOffset: 18, total: 12320, tax: 1320, advance: 5000, balance: 7320, adults: 2, children: 0 },
    { reference: 'RW-ARRIVAL-001', guestName: 'Aarav Nair', email: 'arrival.one@rainwood.demo', mobile: '+91 90000 20001', source: 'WEBSITE' as const, status: 'CONFIRMED' as const, paymentStatus: 'PAID' as const, syncStatus: 'SYNCED' as const, arrivalOffset: 0, total: 11000, tax: 1000, advance: 11000, balance: 0, adults: 2, children: 0 },
    { reference: 'RW-ARRIVAL-002', guestName: 'Diya Menon', email: 'arrival.two@rainwood.demo', mobile: '+91 90000 20002', source: 'AGENT' as const, status: 'TENTATIVE' as const, paymentStatus: 'PARTIALLY_PAID' as const, syncStatus: 'SYNCED' as const, arrivalOffset: 0, total: 13200, tax: 1200, advance: 6600, balance: 6600, adults: 2, children: 1 },
    { reference: 'RW-ARRIVAL-003', guestName: 'Kabir Thomas', email: 'arrival.three@rainwood.demo', mobile: '+91 90000 20003', source: 'DIRECT' as const, status: 'CONFIRMED' as const, paymentStatus: 'PENDING' as const, syncStatus: 'PENDING' as const, arrivalOffset: 0, total: 9800, tax: 800, advance: 0, balance: 9800, adults: 1, children: 0 },
  ];
  for (const item of demoReservations) {
    const checkIn = demoDate(item.arrivalOffset);
    const checkOut = demoDate(item.arrivalOffset + 2);
    const existing = await prisma.reservation.findUnique({ where: { reference: item.reference } });
    const reservation = existing ?? await prisma.reservation.create({ data: { reference: item.reference, hotelId: hotel.id, source: item.source, sourceName: 'RainWood demo seed', status: item.status, paymentStatus: item.paymentStatus, syncStatus: item.syncStatus, guestName: item.guestName, email: item.email, mobile: item.mobile, checkIn, checkOut, currency: 'INR', totalAmount: item.total, taxAmount: item.tax, advanceAmount: item.advance, balanceAmount: item.balance, priceSnapshot: [{ roomTypeId: room.id, ratePlanId: plan.id, amount: item.total - item.tax, taxAmount: item.tax }], policySnapshot: { freeCancellationHours: 48, firstNightPenalty: true, seeded: true }, internalRemark: 'Development seed record', createdById: admin.id, lines: { create: { roomTypeId: room.id, ratePlanId: plan.id, checkIn, checkOut, rooms: 1, adults: item.adults, children: item.children, nightlyRate: Math.round((item.total - item.tax) / 2), taxAmount: item.tax, lineTotal: item.total, priceSnapshot: { amount: item.total - item.tax, taxAmount: item.tax }, nights: { create: [item.arrivalOffset, item.arrivalOffset + 1].map((nightOffset) => ({ date: demoDate(nightOffset), rooms: 1, amount: Math.round((item.total - item.tax) / 2), taxAmount: Math.round(item.tax / 2), totalAmount: Math.round(item.total / 2) })) } } } } });
    if (existing) {
      await prisma.reservation.update({ where: { id: existing.id }, data: { hotelId: hotel.id, source: item.source, sourceName: 'Direct booking demonstration', status: item.status, paymentStatus: item.paymentStatus, syncStatus: item.syncStatus, guestName: item.guestName, email: item.email, mobile: item.mobile, checkIn, checkOut, totalAmount: item.total, taxAmount: item.tax, advanceAmount: item.advance, balanceAmount: item.balance, priceSnapshot: [{ roomTypeId: room.id, ratePlanId: plan.id, amount: item.total - item.tax, taxAmount: item.tax }], policySnapshot: { freeCancellationHours: 48, firstNightPenalty: true, seeded: true }, internalRemark: 'Standard demonstration record' } });
      const existingLine = await prisma.reservationLine.findFirst({ where: { reservationId: existing.id } });
      if (existingLine) await prisma.reservationLine.update({ where: { id: existingLine.id }, data: { roomTypeId: room.id, ratePlanId: plan.id, checkIn, checkOut, rooms: 1, adults: item.adults, children: item.children, nightlyRate: Math.round((item.total - item.tax) / 2), taxAmount: item.tax, lineTotal: item.total, priceSnapshot: { amount: item.total - item.tax, taxAmount: item.tax }, nights: { deleteMany: {}, create: [item.arrivalOffset, item.arrivalOffset + 1].map((nightOffset) => ({ date: demoDate(nightOffset), rooms: 1, amount: Math.round((item.total - item.tax) / 2), taxAmount: Math.round(item.tax / 2), totalAmount: Math.round(item.total / 2) })) } } });
    }
    const paymentAmount = item.reference === 'RW-DEMO-001' ? 6000 : item.reference === 'RW-DEMO-003' ? 12320 : item.reference === 'RW-DEMO-004' ? 5000 : item.reference === 'RW-ARRIVAL-001' ? 11000 : 0;
    if (paymentAmount) await prisma.payment.upsert({ where: { id: `seed-payment-${item.reference}` }, update: { amount: paymentAmount, verified: true, verifiedById: admin.id, paidAt: demoDate(-1) }, create: { id: `seed-payment-${item.reference}`, reservationId: reservation.id, amount: paymentAmount, mode: item.reference === 'RW-DEMO-004' ? 'BANK_TRANSFER' : 'UPI', provider: 'MANUAL', reference: `DEMO-PAY-${item.reference.slice(-3)}`, verified: true, verifiedById: admin.id, paidAt: demoDate(-1) } });
    await prisma.axisSyncLog.upsert({ where: { idempotencyKey: `seed-sync-${item.reference}` }, update: { status: item.syncStatus, response: { seeded: true } }, create: { reservationId: reservation.id, idempotencyKey: `seed-sync-${item.reference}`, direction: 'OUTBOUND', entityType: 'RESERVATION', externalReference: `AXIS-${item.reference}`, status: item.syncStatus, payload: { reference: item.reference, seeded: true }, response: item.syncStatus === 'SYNCED' ? { accepted: true } : undefined } });
    await prisma.outboxJob.upsert({ where: { idempotencyKey: `seed-job-${item.reference}` }, update: { status: item.syncStatus === 'SYNCED' ? 'SUCCEEDED' : 'PENDING' }, create: { type: 'AXIS_BOOKING_PUSH', aggregateType: 'Reservation', aggregateId: reservation.id, idempotencyKey: `seed-job-${item.reference}`, payload: { reservationId: reservation.id, reference: item.reference }, status: item.syncStatus === 'SYNCED' ? 'SUCCEEDED' : 'PENDING', completedAt: item.syncStatus === 'SYNCED' ? demoDate(-1) : undefined } });
    await prisma.auditLog.create({ data: { actorUserId: admin.id, action: 'SEED_RESERVATION', entityType: 'Reservation', entityId: reservation.id, after: { reference: item.reference, status: item.status, seeded: true } } });
  }
  for (const canonicalPlan of canonicalPlans.filter((item) => item.code !== 'CP')) for (let offset = 0; offset < 120; offset += 1) {
    const date = new Date(start.getTime() + offset * 86_400_000);
    const amount = canonicalPlan.code === 'EP' ? 5000 : canonicalPlan.code === 'MAP' ? 6500 : 7800;
    await prisma.rateDay.upsert({ where: { ratePlanId_date: { ratePlanId: canonicalPlan.id, date } }, update: { amount, taxAmount: Math.round(amount * 0.12), childAmount: 1000, extraAdultAmount: 1500, minLos: 1, maxLos: 30 }, create: { ratePlanId: canonicalPlan.id, date, amount, taxAmount: Math.round(amount * 0.12), childAmount: 1000, extraAdultAmount: 1500, minLos: 1, maxLos: 30 } });
  }
  const corporate = await prisma.corporateAccount.upsert({
    where: { id: 'seed-corporate-account' },
    update: { name: 'Mountain View Conferences', legalName: 'Mountain View Conferences Private Limited', gstin: '33AACCM1234L1Z6', pan: 'AACCM1234L', billingAddress: '18 Lake Road', city: 'Coimbatore', state: 'Tamil Nadu', country: 'India', postalCode: '641001', contactPerson: 'Neha Iyer', email: 'accounts@mountainview.example', mobile: '+91 90000 30001', creditLimit: 250000, creditDays: 30, active: true },
    create: { id: 'seed-corporate-account', name: 'Mountain View Conferences', legalName: 'Mountain View Conferences Private Limited', gstin: '33AACCM1234L1Z6', pan: 'AACCM1234L', billingAddress: '18 Lake Road', city: 'Coimbatore', state: 'Tamil Nadu', country: 'India', postalCode: '641001', contactPerson: 'Neha Iyer', email: 'accounts@mountainview.example', mobile: '+91 90000 30001', creditLimit: 250000, creditDays: 30, active: true },
  });
  await prisma.corporateAccountHotel.upsert({ where: { corporateAccountId_hotelId: { corporateAccountId: corporate.id, hotelId: hotel.id } }, update: { active: true, accountCode: 'MVC-001', creditLimitOverride: 250000, creditDaysOverride: 30 }, create: { corporateAccountId: corporate.id, hotelId: hotel.id, active: true, accountCode: 'MVC-001', creditLimitOverride: 250000, creditDaysOverride: 30 } });
  await prisma.corporateRateAgreement.upsert({ where: { id: 'seed-corporate-rate-agreement' }, update: { corporateAccountId: corporate.id, hotelId: hotel.id, roomTypeId: room.id, ratePlanId: plan.id, validFrom: taxEffectiveFrom, validTo: taxEffectiveTo, pricingType: 'DISCOUNT_PERCENT', fixedRate: null, discountPercent: 10, active: true }, create: { id: 'seed-corporate-rate-agreement', corporateAccountId: corporate.id, hotelId: hotel.id, roomTypeId: room.id, ratePlanId: plan.id, validFrom: taxEffectiveFrom, validTo: taxEffectiveTo, pricingType: 'DISCOUNT_PERCENT', discountPercent: 10, active: true } });
  const corporateReservation = await prisma.reservation.findUniqueOrThrow({ where: { reference: 'RW-DEMO-002' } });
  await prisma.reservation.update({ where: { id: corporateReservation.id }, data: { corporateAccountId: corporate.id, corporateSnapshot: { name: corporate.name, legalName: corporate.legalName, gstin: corporate.gstin, state: corporate.state, stateCode: '33', billingAddress: corporate.billingAddress } } });
  const financialYear = today.getUTCMonth() >= 3 ? `${today.getUTCFullYear()}-${String(today.getUTCFullYear() + 1).slice(-2)}` : `${today.getUTCFullYear() - 1}-${String(today.getUTCFullYear()).slice(-2)}`;
  const taxInvoice = await prisma.taxInvoice.upsert({ where: { id: 'seed-tax-invoice-001' }, update: { hotelId: hotel.id, taxProfileId: 'seed-hotel-tax-profile', invoiceNo: 'INV-DEMO-001', invoiceDate: demoDate(-1), financialYear, status: 'ISSUED', reservationId: corporateReservation.id, customerType: 'CORPORATE', customerName: corporate.name, customerGstin: corporate.gstin, customerAddress: corporate.billingAddress, customerState: corporate.state, customerStateCode: '33', customerEmail: corporate.email, customerMobile: corporate.mobile, hotelLegalName: 'RainWood Hospitality Services Private Limited', hotelTradeName: hotel.name, hotelGstin: '33AAECR1234K1Z5', hotelAddress: 'Survey 12, Observatory Road', hotelCity: 'Kodaikanal', hotelState: 'Tamil Nadu', hotelStateCode: '33', hotelPostalCode: '624101', placeOfSupplyState: 'Tamil Nadu', placeOfSupplyStateCode: '33', taxableAmount: 10000, cgstAmount: 900, sgstAmount: 900, igstAmount: 0, otherTaxAmount: 0, roundOff: 0, grandTotal: 11800, currency: 'INR', issuedById: admin.id, issuedAt: demoDate(-1) }, create: { id: 'seed-tax-invoice-001', hotelId: hotel.id, taxProfileId: 'seed-hotel-tax-profile', invoiceNo: 'INV-DEMO-001', invoiceDate: demoDate(-1), financialYear, status: 'ISSUED', reservationId: corporateReservation.id, customerType: 'CORPORATE', customerName: corporate.name, customerGstin: corporate.gstin, customerAddress: corporate.billingAddress, customerState: corporate.state, customerStateCode: '33', customerEmail: corporate.email, customerMobile: corporate.mobile, hotelLegalName: 'RainWood Hospitality Services Private Limited', hotelTradeName: hotel.name, hotelGstin: '33AAECR1234K1Z5', hotelAddress: 'Survey 12, Observatory Road', hotelCity: 'Kodaikanal', hotelState: 'Tamil Nadu', hotelStateCode: '33', hotelPostalCode: '624101', placeOfSupplyState: 'Tamil Nadu', placeOfSupplyStateCode: '33', taxableAmount: 10000, cgstAmount: 900, sgstAmount: 900, igstAmount: 0, otherTaxAmount: 0, roundOff: 0, grandTotal: 11800, currency: 'INR', issuedById: admin.id, issuedAt: demoDate(-1) } });
  const taxInvoiceLine = await prisma.taxInvoiceLine.upsert({ where: { id: 'seed-tax-invoice-line-001' }, update: { invoiceId: taxInvoice.id, taxRuleId: 'seed-tax-rule-room', lineType: 'ROOM', description: 'Premium Valley Room accommodation', serviceCode: '996311', quantity: 2, unitAmount: 5000, taxableAmount: 10000, taxRate: 18, cgstRate: 9, cgstAmount: 900, sgstRate: 9, sgstAmount: 900, igstRate: 0, igstAmount: 0, lineTotal: 11800, sourceType: 'ROOM_STAY', sourceId: corporateReservation.id }, create: { id: 'seed-tax-invoice-line-001', invoiceId: taxInvoice.id, taxRuleId: 'seed-tax-rule-room', lineType: 'ROOM', description: 'Premium Valley Room accommodation', serviceCode: '996311', quantity: 2, unitAmount: 5000, taxableAmount: 10000, taxRate: 18, cgstRate: 9, cgstAmount: 900, sgstRate: 9, sgstAmount: 900, igstRate: 0, igstAmount: 0, lineTotal: 11800, sourceType: 'ROOM_STAY', sourceId: corporateReservation.id } });
  const creditNote = await prisma.taxCreditNote.upsert({ where: { id: 'seed-credit-note-001' }, update: { hotelId: hotel.id, invoiceId: taxInvoice.id, creditNoteNo: 'CN-DEMO-001', creditNoteDate: demoDate(-1), financialYear, reason: 'Courtesy adjustment for a shortened stay', status: 'ISSUED', taxableAmount: 500, cgstAmount: 45, sgstAmount: 45, igstAmount: 0, roundOff: 0, grandTotal: 590, issuedById: admin.id, issuedAt: demoDate(-1), hotelTaxProfileId: 'seed-hotel-tax-profile' }, create: { id: 'seed-credit-note-001', hotelId: hotel.id, invoiceId: taxInvoice.id, creditNoteNo: 'CN-DEMO-001', creditNoteDate: demoDate(-1), financialYear, reason: 'Courtesy adjustment for a shortened stay', status: 'ISSUED', taxableAmount: 500, cgstAmount: 45, sgstAmount: 45, igstAmount: 0, roundOff: 0, grandTotal: 590, issuedById: admin.id, issuedAt: demoDate(-1), hotelTaxProfileId: 'seed-hotel-tax-profile' } });
  await prisma.taxCreditNoteLine.upsert({ where: { id: 'seed-credit-note-line-001' }, update: { creditNoteId: creditNote.id, invoiceLineId: taxInvoiceLine.id, description: 'Credit against room accommodation', serviceCode: '996311', taxableAmount: 500, taxRate: 18, cgstAmount: 45, sgstAmount: 45, igstAmount: 0, lineTotal: 590 }, create: { id: 'seed-credit-note-line-001', creditNoteId: creditNote.id, invoiceLineId: taxInvoiceLine.id, description: 'Credit against room accommodation', serviceCode: '996311', taxableAmount: 500, taxRate: 18, cgstAmount: 45, sgstAmount: 45, igstAmount: 0, lineTotal: 590 } });
  await prisma.tdsDeduction.upsert({ where: { id: 'seed-tds-001' }, update: { hotelId: hotel.id, corporateAccountId: corporate.id, taxInvoiceId: taxInvoice.id, deductionDate: demoDate(-1), sectionCode: '194-I', ratePercent: 2, grossInvoiceAmount: 11800, tdsAmount: 300, certificateNumber: null, certificateDate: null, financialYear, status: 'CERTIFICATE_PENDING', notes: 'Certificate pending from corporate accounts.', recordedById: admin.id }, create: { id: 'seed-tds-001', hotelId: hotel.id, corporateAccountId: corporate.id, taxInvoiceId: taxInvoice.id, deductionDate: demoDate(-1), sectionCode: '194-I', ratePercent: 2, grossInvoiceAmount: 11800, tdsAmount: 300, financialYear, status: 'CERTIFICATE_PENDING', notes: 'Certificate pending from corporate accounts.', recordedById: admin.id } });
  const inquiryRows = [
    { id: 'seed-inquiry-001', hotelId: hotel.id, inquiryNo: 'INQ-DEMO-001', guestName: 'Maya Iyer', mobile: '+91 90000 40001', email: 'maya.iyer@example.com', source: 'WEBSITE' as const, checkIn: demoDate(4), checkOut: demoDate(6), adults: 2, children: 1, roomTypeId: room.id, status: 'NEW' as const, assignedToId: reservationUser.id, nextFollowUpAt: demoDate(1), notes: 'Family holiday enquiry for a valley-view room.' },
    { id: 'seed-inquiry-002', hotelId: hotel.id, inquiryNo: 'INQ-DEMO-002', guestName: 'Rohan Desai', mobile: '+91 90000 40002', email: 'rohan.desai@example.com', source: 'PHONE' as const, checkIn: demoDate(8), checkOut: demoDate(10), adults: 2, children: 0, roomTypeId: room.id, status: 'FOLLOW_UP' as const, assignedToId: reservationUser.id, nextFollowUpAt: demoDate(2), notes: 'Requested a weekday corporate rate.', quotedAmount: 9900, quotedAt: demoDate(-1), quoteSnapshot: { source: 'standard corporate quote', amount: 9900 } },
    { id: 'seed-inquiry-003', hotelId: hotel.id, inquiryNo: 'INQ-DEMO-003', guestName: 'Sana Joseph', mobile: '+91 90000 40003', email: 'sana.joseph@example.com', source: 'COMPANY' as const, checkIn: demoDate(3), checkOut: demoDate(5), adults: 1, children: 0, roomTypeId: room.id, status: 'CONVERTED' as const, assignedToId: reservationUser.id, nextFollowUpAt: null, notes: 'Converted to the existing reservation flow.', convertedReservationId: (await prisma.reservation.findUniqueOrThrow({ where: { reference: 'RW-DEMO-001' } })).id },
  ];
  for (const inquiry of inquiryRows) await prisma.bookingInquiry.upsert({ where: { id: inquiry.id }, update: { ...inquiry }, create: { ...inquiry } });
  await prisma.inquiryFollowUp.upsert({ where: { id: 'seed-inquiry-follow-up-001' }, update: { inquiryId: 'seed-inquiry-002', method: 'CALL', note: 'Shared the weekday corporate rate and requested a response.', nextFollowUpAt: demoDate(2), createdById: admin.id }, create: { id: 'seed-inquiry-follow-up-001', inquiryId: 'seed-inquiry-002', method: 'CALL', note: 'Shared the weekday corporate rate and requested a response.', nextFollowUpAt: demoDate(2), createdById: admin.id } });
  await prisma.paymentAttempt.upsert({ where: { idempotencyKey: 'seed-payment-attempt-pending' }, update: { status: 'PENDING' }, create: { reservationId: (await prisma.reservation.findUniqueOrThrow({ where: { reference: 'RW-DEMO-002' } })).id, provider: 'RAZORPAY', providerOrderId: 'seed-order-rw-demo-002', idempotencyKey: 'seed-payment-attempt-pending', amount: 12320, currency: 'INR', status: 'PENDING', expiresAt: demoDate(10) } });
  const holdReservation = await prisma.reservation.findUniqueOrThrow({ where: { reference: 'RW-DEMO-002' } });
  await prisma.inventoryHold.upsert({ where: { tokenHash: 'seed-active-hold-token-hash' }, update: { status: 'ACTIVE', expiresAt: new Date(Date.now() + 1_800_000) }, create: { tokenHash: 'seed-active-hold-token-hash', hotelId: hotel.id, status: 'ACTIVE', guestEmail: 'vikram.menon@example.com', expiresAt: new Date(Date.now() + 1_800_000), lines: { create: { roomTypeId: room.id, ratePlanId: plan.id, checkIn: demoDate(10), checkOut: demoDate(12), rooms: 1, adults: 2, children: 1, quotedTotal: 12320, quotedTax: 1320, quotedBreakdown: { seeded: true, amount: 5500 }, nights: { create: [10, 11].map((offset) => ({ date: demoDate(offset), rooms: 1 })) } } } } });
  const housekeepingPasswordHash = await bcrypt.hash(process.env.SEED_STAFF_PASSWORD ?? 'StaffDemo@2026!', 12);
  await prisma.user.upsert({ where: { email: 'service.staff.test@rainwood.demo' }, update: { name: 'Lakshmi Room Attendant', passwordHash: housekeepingPasswordHash, role: 'SERVICE_STAFF', staffDepartment: 'HOUSEKEEPING', jobTitle: 'Room Attendant', staffHotelId: hotel.id, active: true }, create: { email: 'service.staff.test@rainwood.demo', name: 'Lakshmi Room Attendant', passwordHash: housekeepingPasswordHash, role: 'SERVICE_STAFF', staffDepartment: 'HOUSEKEEPING', jobTitle: 'Room Attendant', staffHotelId: hotel.id, active: true } });
  await prisma.user.upsert({ where: { email: 'maintenance.staff.test@rainwood.demo' }, update: { name: 'Suresh Maintenance Technician', passwordHash: housekeepingPasswordHash, role: 'SERVICE_STAFF', staffDepartment: 'MAINTENANCE', jobTitle: 'Maintenance Technician', staffHotelId: hotel.id, active: true }, create: { email: 'maintenance.staff.test@rainwood.demo', name: 'Suresh Maintenance Technician', passwordHash: housekeepingPasswordHash, role: 'SERVICE_STAFF', staffDepartment: 'MAINTENANCE', jobTitle: 'Maintenance Technician', staffHotelId: hotel.id, active: true } });
  const demoRoom203 = seededRooms.find((item) => item.roomNumber === '203')!;
  await prisma.maintenanceTicket.upsert({ where: { id: 'seed-maintenance-ticket-203' }, update: { hotelId: hotel.id, roomId: demoRoom203.id, source: 'ADMIN', category: 'HVAC', priority: 'HIGH', status: 'OPEN', title: 'AC inspection · Room 203', description: 'Air conditioner is not cooling consistently. Demo engineering ticket.', reportedById: admin.id, assignedToId: null, assignedAt: null, startedAt: null, completedAt: null, resolutionNote: null, requiresOutOfOrder: false, outOfOrderAppliedAt: null, outOfOrderClearedAt: null }, create: { id: 'seed-maintenance-ticket-203', hotelId: hotel.id, roomId: demoRoom203.id, source: 'ADMIN', category: 'HVAC', priority: 'HIGH', status: 'OPEN', title: 'AC inspection · Room 203', description: 'Air conditioner is not cooling consistently. Demo engineering ticket.', reportedById: admin.id, createdById: admin.id } });
  const ballroom = await prisma.functionSpace.upsert({ where: { id: 'seed-function-space-ballroom' }, update: { hotelId: hotel.id, name: 'Grand Ballroom', code: 'BALLROOM', spaceType: 'BALLROOM', active: true, outOfService: false, capacityTheatre: 200, capacityClassroom: 120, capacityBoardroom: 48, capacityUShape: 60, capacityBanquet: 160, capacityReception: 260, notes: 'Main event venue with stage and foyer access.' }, create: { id: 'seed-function-space-ballroom', hotelId: hotel.id, name: 'Grand Ballroom', code: 'BALLROOM', spaceType: 'BALLROOM', active: true, outOfService: false, capacityTheatre: 200, capacityClassroom: 120, capacityBoardroom: 48, capacityUShape: 60, capacityBanquet: 160, capacityReception: 260, notes: 'Main event venue with stage and foyer access.' } });
  await prisma.functionSpace.upsert({ where: { id: 'seed-function-space-boardroom' }, update: { hotelId: hotel.id, name: 'Board Room 1', code: 'BOARDROOM-1', spaceType: 'BOARDROOM', active: true, outOfService: false, capacityTheatre: 24, capacityClassroom: 12, capacityBoardroom: 14, capacityUShape: 16, capacityBanquet: 12, capacityReception: 30, notes: 'Executive meeting room with display.' }, create: { id: 'seed-function-space-boardroom', hotelId: hotel.id, name: 'Board Room 1', code: 'BOARDROOM-1', spaceType: 'BOARDROOM', active: true, outOfService: false, capacityTheatre: 24, capacityClassroom: 12, capacityBoardroom: 14, capacityUShape: 16, capacityBanquet: 12, capacityReception: 30, notes: 'Executive meeting room with display.' } });
  const banquetDate = demoDate(5); const banquetDateText = banquetDate.toISOString().slice(0, 10); const banquetYear = banquetDate.getUTCFullYear();
  await prisma.documentSequence.upsert({ where: { hotelId_type_year: { hotelId: hotel.id, type: 'BANQUET_EVENT', year: banquetYear } }, update: { lastNumber: 1 }, create: { hotelId: hotel.id, type: 'BANQUET_EVENT', year: banquetYear, lastNumber: 1 } });
  const banquet = await prisma.banquetEvent.upsert({ where: { id: 'seed-banquet-event-001' }, update: { hotelId: hotel.id, eventCode: `BQT-${hotel.code}-${banquetYear}-000001`, eventName: 'Mountain View Annual Conference', eventType: 'CONFERENCE', status: 'CONFIRMED', corporateId: corporate.id, primaryContactName: 'Neha Iyer', primaryContactMobile: '+91 90000 30001', primaryContactEmail: 'accounts@mountainview.example', startDate: banquetDate, endDate: banquetDate, expectedPax: 180, guaranteedPax: 150, notes: 'Seeded banquet event for the function-space and BEO workspace.', createdByUserId: admin.id }, create: { id: 'seed-banquet-event-001', hotelId: hotel.id, eventCode: `BQT-${hotel.code}-${banquetYear}-000001`, eventName: 'Mountain View Annual Conference', eventType: 'CONFERENCE', status: 'CONFIRMED', corporateId: corporate.id, primaryContactName: 'Neha Iyer', primaryContactMobile: '+91 90000 30001', primaryContactEmail: 'accounts@mountainview.example', startDate: banquetDate, endDate: banquetDate, expectedPax: 180, guaranteedPax: 150, notes: 'Seeded banquet event for the function-space and BEO workspace.', createdByUserId: admin.id } });
  const banquetFunction = await prisma.banquetFunction.upsert({ where: { id: 'seed-banquet-function-001' }, update: { banquetEventId: banquet.id, functionSpaceId: ballroom.id, functionName: 'Main Conference Session', functionDate: banquetDate, startTime: '09:00', endTime: '17:00', startAt: new Date(`${banquetDateText}T03:30:00.000Z`), endAt: new Date(`${banquetDateText}T11:30:00.000Z`), setupStyle: 'THEATRE', expectedPax: 180, guaranteedPax: 150, status: 'CONFIRMED', notes: 'Main plenary session.' }, create: { id: 'seed-banquet-function-001', banquetEventId: banquet.id, functionSpaceId: ballroom.id, functionName: 'Main Conference Session', functionDate: banquetDate, startTime: '09:00', endTime: '17:00', startAt: new Date(`${banquetDateText}T03:30:00.000Z`), endAt: new Date(`${banquetDateText}T11:30:00.000Z`), setupStyle: 'THEATRE', expectedPax: 180, guaranteedPax: 150, status: 'CONFIRMED', notes: 'Main plenary session.' } });
  await prisma.documentSequence.upsert({ where: { hotelId_type_year: { hotelId: hotel.id, type: 'BANQUET_BEO', year: banquetYear } }, update: { lastNumber: 1 }, create: { hotelId: hotel.id, type: 'BANQUET_BEO', year: banquetYear, lastNumber: 1 } });
  const banquetBeo = await prisma.banquetEventOrder.upsert({ where: { banquetFunctionId: banquetFunction.id }, update: { beoNumber: `BEO-${hotel.code}-${banquetYear}-000001`, status: 'FINAL', finalizedAt: demoDate(2), finalizedById: admin.id, operationalNotes: 'Final operational brief for the seeded conference.' }, create: { id: 'seed-banquet-beo-001', banquetFunctionId: banquetFunction.id, beoNumber: `BEO-${hotel.code}-${banquetYear}-000001`, status: 'FINAL', finalizedAt: demoDate(2), finalizedById: admin.id, operationalNotes: 'Final operational brief for the seeded conference.' } });
  await prisma.banquetScheduleItem.deleteMany({ where: { beoId: banquetBeo.id } });
  await prisma.banquetScheduleItem.createMany({ data: [{ id: 'seed-banquet-schedule-001', beoId: banquetBeo.id, itemTime: '07:00', description: 'Hall access and setup', sortOrder: 0 }, { id: 'seed-banquet-schedule-002', beoId: banquetBeo.id, itemTime: '08:30', description: 'Registration desk opens', sortOrder: 1 }, { id: 'seed-banquet-schedule-003', beoId: banquetBeo.id, itemTime: '13:00', description: 'Lunch service', sortOrder: 2 }] });
  await prisma.banquetRequirement.deleteMany({ where: { beoId: banquetBeo.id } });
  await prisma.banquetRequirement.createMany({ data: [{ id: 'seed-banquet-requirement-001', beoId: banquetBeo.id, category: 'AUDIO_VISUAL', description: 'Projector and HDMI presentation kit', quantity: 1, requiredAt: '08:00', department: 'ENGINEERING', status: 'COMPLETED' }, { id: 'seed-banquet-requirement-002', beoId: banquetBeo.id, category: 'AUDIO_VISUAL', description: 'Wireless microphones', quantity: 2, requiredAt: '08:00', department: 'SERVICE', status: 'ACKNOWLEDGED' }, { id: 'seed-banquet-requirement-003', beoId: banquetBeo.id, category: 'FOOD_BEVERAGE', description: 'Tea break and lunch for guaranteed PAX', quantity: 150, requiredAt: '13:00', department: 'FOOD_BEVERAGE', status: 'PENDING' }] });
  await prisma.banquetChargeLine.deleteMany({ where: { beoId: banquetBeo.id } });
  await prisma.banquetChargeLine.createMany({ data: [{ id: 'seed-banquet-charge-001', beoId: banquetBeo.id, category: 'VENUE_RENTAL', description: 'Grand Ballroom day rental', quantity: 1, unitAmount: 45000, totalAmount: 45000 }, { id: 'seed-banquet-charge-002', beoId: banquetBeo.id, category: 'FOOD_PACKAGE', description: 'Conference lunch package', quantity: 150, unitAmount: 850, totalAmount: 127500 }] });
  for (const featureKey of FEATURE_KEYS) await prisma.featureSetting.upsert({ where: { featureKey }, update: {}, create: { featureKey, enabled: true } });
  console.log(`Seeded development data for ${admin.email}`);
}

main().catch((error) => { console.error(error); process.exitCode = 1; }).finally(async () => { await prisma.$disconnect(); await pool.end(); });
