import { ConflictException, ForbiddenException } from '@nestjs/common';
import { BookingSource, InquiryStatus, UserRole } from '@prisma/client';
import { InquiriesService } from './inquiries.service';

describe('InquiriesService', () => {
  const p: any = { user: { findUnique: jest.fn(), findFirst: jest.fn() }, hotel: { findUnique: jest.fn() }, documentSequence: { upsert: jest.fn() }, roomType: { findFirst: jest.fn() }, guestProfile: { findFirst: jest.fn() }, bookingInquiry: { count: jest.fn(), findMany: jest.fn(), groupBy: jest.fn(), findUnique: jest.fn(), create: jest.fn(), update: jest.fn(), updateMany: jest.fn() }, inquiryFollowUp: { create: jest.fn() }, reservation: { findUnique: jest.fn() }, $transaction: jest.fn() };
  const audit = { log: jest.fn() } as any;
  const actor = (role: UserRole = UserRole.RESERVATION, hotelId: string | null = 'hotel-a') => ({ id: 'user-1', role, staffHotelId: hotelId, staffDepartment: null, staffHotel: { id: hotelId, active: true } });
  let service: InquiriesService;
  beforeEach(() => { jest.clearAllMocks(); service = new InquiriesService(p, audit); p.user.findUnique.mockResolvedValue(actor()); p.hotel.findUnique.mockResolvedValue({ id: 'hotel-a', name: 'A', active: true }); p.documentSequence.upsert.mockResolvedValue({ lastNumber: 1 }); p.roomType.findFirst.mockResolvedValue({ id: 'room-1', hotelId: 'hotel-a', active: true }); p.guestProfile.findFirst.mockResolvedValue(null); p.bookingInquiry.count.mockResolvedValue(0); p.bookingInquiry.create.mockImplementation(async ({ data }: any) => ({ id: 'inq-1', ...data, quotedAmount: null, hotel: { id: 'hotel-a', name: 'A' }, roomType: null, assignedTo: null, followUps: [], convertedReservation: null })); });

  it('creates an inquiry without creating a guest profile', async () => { const result = await service.create('user-1', { hotelId: 'hotel-a', guestName: 'Synthetic Guest', mobile: '9999999999', source: BookingSource.PHONE }); expect(result.inquiryNo).toBe('INQ-2026-000001'); expect(p.guestProfile.findFirst).toHaveBeenCalled(); expect(p.guestProfile.create).toBeUndefined(); });
  it('rejects cross-hotel creation', async () => { await expect(service.create('user-1', { hotelId: 'hotel-b', guestName: 'Guest', mobile: '9999999999', source: BookingSource.PHONE })).rejects.toBeInstanceOf(ForbiddenException); });
  it('keeps follow-up history and moves to follow-up', async () => { const current: any = { id: 'inq-1', status: InquiryStatus.NEW }; jest.spyOn(service, 'detail').mockResolvedValue(current); const tx: any = { inquiryFollowUp: { create: jest.fn() }, bookingInquiry: { update: jest.fn().mockResolvedValue({ ...current, status: InquiryStatus.FOLLOW_UP, followUps: [] }) } }; p.$transaction.mockImplementation((callback: any) => callback(tx)); const result = await service.followUp('user-1', 'inq-1', { method: 'CALL', note: 'Sent synthetic quote' }); expect(tx.inquiryFollowUp.create).toHaveBeenCalled(); expect(result.status).toBe(InquiryStatus.FOLLOW_UP); });
  it('converts by linking exactly one existing reservation and is retry-safe', async () => { p.user.findUnique.mockResolvedValue(actor(UserRole.ADMIN)); p.bookingInquiry.findUnique.mockResolvedValue({ id: 'inq-1', hotelId: 'hotel-a', convertedReservationId: null, status: InquiryStatus.QUOTE_SENT }); p.reservation.findUnique.mockResolvedValue({ id: 'res-1', reference: 'RW-1', hotelId: 'hotel-a' }); p.bookingInquiry.updateMany.mockResolvedValue({ count: 1 }); const result = await service.convert('user-1', 'inq-1', { reservationReference: 'RW-1' }); expect(result.reservation.id).toBe('res-1'); expect(p.bookingInquiry.updateMany).toHaveBeenCalledWith(expect.objectContaining({ where: expect.objectContaining({ convertedReservationId: null }) })); p.bookingInquiry.findUnique.mockResolvedValue({ id: 'inq-1', hotelId: 'hotel-a', convertedReservationId: 'res-1', status: InquiryStatus.CONVERTED }); const retry = await service.convert('user-1', 'inq-1', { reservationReference: 'RW-1' }); expect(retry.status).toBe(InquiryStatus.CONVERTED); });
  it('rejects a conversion retry to another reservation', async () => { p.bookingInquiry.findUnique.mockResolvedValue({ id: 'inq-1', hotelId: 'hotel-a', convertedReservationId: 'res-1', status: InquiryStatus.CONVERTED }); p.reservation.findUnique.mockResolvedValue({ id: 'res-2', reference: 'RW-2', hotelId: 'hotel-a' }); await expect(service.convert('user-1', 'inq-1', { reservationReference: 'RW-2' })).rejects.toBeInstanceOf(ConflictException); });

  it('validates effective room, assignee, and merged stay dates on update', async () => {
    jest.spyOn(service, 'detail').mockResolvedValue({ id: 'inq-1', hotelId: 'hotel-a', status: InquiryStatus.NEW, roomTypeId: 'room-1', assignedToId: 'user-1', checkIn: '2026-10-10', checkOut: '2026-10-12' } as any);
    p.roomType.findFirst.mockResolvedValue(null);
    await expect(service.update('user-1', 'inq-1', { roomTypeId: 'room-from-other-hotel' })).rejects.toThrow('Room type is not available');
    p.roomType.findFirst.mockResolvedValue({ id: 'room-1', hotelId: 'hotel-a', active: true });
    await expect(service.update('user-1', 'inq-1', { checkOut: '2026-10-09' })).rejects.toThrow('checkOut must be after');
  });

  it('does not allow generic PATCH or closed inquiries to bypass lifecycle actions', async () => {
    jest.spyOn(service, 'detail').mockResolvedValue({ id: 'inq-1', hotelId: 'hotel-a', status: InquiryStatus.LOST, roomTypeId: 'room-1', checkIn: '2026-10-10', checkOut: '2026-10-12' } as any);
    await expect(service.quote('user-1', 'inq-1', { ratePlanId: 'plan-1', rooms: 1, adults: 2, children: 0 })).rejects.toBeInstanceOf(ConflictException);
    await expect(service.markLost('user-1', 'inq-1', { lostReason: 'again' })).rejects.toBeInstanceOf(ConflictException);
  });
});
